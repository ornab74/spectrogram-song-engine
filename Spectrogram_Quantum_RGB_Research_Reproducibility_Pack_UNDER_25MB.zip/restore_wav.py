#!/usr/bin/env python3
"""Restore PCM-identical stereo WAV from this bundle's lossless FLAC.
Requires: pip install soundfile
"""
from pathlib import Path
import soundfile as sf

flac=Path(__file__).with_name('original_audio_lossless.flac')
output=Path(__file__).with_name('Punchier Pre-Chorus and Chorus (Extended) (1) (1) (1).wav')
with sf.SoundFile(flac, 'r') as source:
    with sf.SoundFile(output, 'w', samplerate=source.samplerate, channels=source.channels, subtype='PCM_16', format='WAV') as target:
        while True:
            block=source.read(262144,dtype='int16',always_2d=True)
            if not len(block):break
            target.write(block)
print(f'Restored {output}')
